import asyncio
import pygame
from math import sqrt, sin, cos, atan, tanh, asin

pygame.init()

# Constants
K = 30
U_MAG = 0.5
ANG_MAG = 0.05
GAIN = 0.1
W0 = 3
XI = 0.7
DT = 1e-2
WIDTH = 1280
HEIGHT = 720
SCALE = 100
FG_COLOR = (210, 210, 210)
BG_COLOR = (36, 39, 58)
Y0 = 1.7

# Global variables
px = 0
px_stored = 0
px_stance = 0
x = [px, Y0, 0.0, 0.0, 0.0, 0.0]
Ts = 0.1
Ts_stored = 0.1
TD_angle = 0
flight = True
failed = False
Raibert = True
running = True
frame = 0
controller = 0
panel = False

screen = pygame.display.set_mode([WIDTH, HEIGHT])
clock = pygame.time.Clock()
floor = pygame.image.load("img/isometric_floor.png").convert_alpha()
spring = pygame.image.load("img/spring.png").convert_alpha()
body = pygame.image.load("img/body.png").convert_alpha()
bg1 = pygame.image.load("img/background1.png").convert_alpha()
bg2 = pygame.image.load("img/background2.png").convert_alpha()
bg3 = pygame.image.load("img/background3.png").convert_alpha()
bg4 = pygame.image.load("img/background4.png").convert_alpha()
background = [bg1, bg2, bg3, bg4]
floor_coordinates = (0, 0)


def ff(x, u, dt, k=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]):
    dx = [x[3], x[4], x[5], 0.0, -1.0, u]
    return [dx[i] + dt * k[i] for i in range(6)]


def fs(x, dt, k=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]):
    l = sqrt(x[0] ** 2 + x[1] ** 2)
    E = 0.5 * (x[3] ** 2 + x[4] ** 2) + l * cos(x[2]) + 0.5 * K * (1 - l) ** 2
    F = -0.5 * tanh(100 * (E - Y0))
    dx = [
        x[3],
        x[4],
        0.0,
        (K * (1 - l) + F * x[3]) * x[0] / l,
        (K * (1.0 - l) + F * x[4]) * x[1] / l - 1.0,
        0.0,
    ]
    return [dx[i] + dt * k[i] for i in range(6)]


def RK4f(x, u):
    k1 = ff(x, u, 0.0)
    k2 = ff(x, u, DT / 2, k1)
    k3 = ff(x, u, DT / 2, k2)
    k4 = ff(x, u, DT, k3)
    return [x[i] + DT / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) for i in range(6)]


def RK4s(x):
    k1 = fs(x, 0.0)
    k2 = fs(x, DT / 2, k1)
    k3 = fs(x, DT / 2, k2)
    k4 = fs(x, DT, k3)
    x_ = [x[i] + DT / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) for i in range(6)]
    x_[2] = atan(-x[0] / x[1])
    x_[5] = x_[0] * x_[4] - x_[1] * x_[3]
    return x_


def TD(x):
    return x[1] < cos(x[2])


def LO(x):
    return x[0] ** 2 + x[1] ** 2 > 1


def uv(P):
    return [P[0] + WIDTH // 2, HEIGHT // 2 - P[1]]


def draw(px, x, flight, floor_coordinates):
    P1 = [0.0, SCALE * x[1]]
    l = 1.0 if flight else sqrt(x[0] ** 2 + x[1] ** 2)
    floor_coordinates = [
        floor_coordinates[0] - SCALE * px,
        floor_coordinates[1] - SCALE * px / 2,
    ]
    if abs(floor_coordinates[0]) > 64:
        floor_coordinates = (floor_coordinates[0] % 64, floor_coordinates[1] % 32)
    screen.blit(
        floor,
        (
            WIDTH // 2 - 800 + floor_coordinates[0],
            HEIGHT // 2 - 408 - floor_coordinates[1],
        ),
    )
    p1 = uv(P1)
    spring_scaled = pygame.transform.scale(
        spring, (32, int(2 * SCALE * (l ))) #- 1 / 2 * sin(x[2])
    )
    spring_rotated = pygame.transform.rotate(spring_scaled, x[2] * 180 / 3.14)
    size_rect = spring_rotated.get_rect().size
    screen.blit(
        spring_rotated,
        (
            p1[0] - size_rect[0] / 2 - l / 2 * sin(x[2]),
            p1[1] - size_rect[1] / 2 - l / 2 * sin(x[2]),
        ),
    )
    pygame.draw.circle(screen, (237, 135, 150), p1, 24)


async def main():

    global px, px_stored, px_stance, x, Ts, Ts_stored, flight, failed, Raibert, running, frame, floor_coordinates, panel, controller, TD_angle

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    panel = not panel

        u = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] or x[1] < 0.0:
            px = 0
            px_stored = 0
            px_stance = 0
            x = [px, Y0, 0.0, 0.0, 0.0, 0.0]
            TD_angle = 0
        if keys[pygame.K_LEFT]:
            u = -1
        if keys[pygame.K_RIGHT]:
            u = 1
        if keys[pygame.K_1]:
            controller = 0
        if keys[pygame.K_2]:
            controller = 1
        if keys[pygame.K_3]:
            controller = 2
        if keys[pygame.K_4]:
            controller = 3

        if not panel:
            if flight:
                if controller == 1:
                    u = u * U_MAG
                if controller == 1:
                    TD_angle += u * ANG_MAG
                    u = W0**2 * (TD_angle - x[2]) - 2 * XI * W0 * x[5]
                if controller == 2:
                    TD_angle = asin((x[3] * Ts / 2))
                    u = W0**2 * (TD_angle - x[2]) - 2 * XI * W0 * x[5]
                if controller == 3:
                    vd = 1.5 * tanh(100 * u)
                    TD_angle = asin((x[3] * Ts / 2) + GAIN * (x[3] - vd))
                    u = W0**2 * (TD_angle - x[2]) - 2 * XI * W0 * x[5]

                x = RK4f(x, u)
                px = x[0]
                if TD(x):
                    flight = False
                    px_stored = px
                    px_stance = -sin(x[2])
                    x[0] = -sin(x[2])
                    Ts_stored = 0
            else:
                x = RK4s(x)
                px = px_stored + x[0] - px_stance
                Ts_stored += DT
                if LO(x):
                    flight = True
                    x[0] = px
                    Ts = Ts_stored
                    TD_angle = 0

            if frame >= 0.06:
                screen.fill(BG_COLOR)
                draw(px, x, flight, floor_coordinates)
                pygame.display.flip()
                clock.tick(60)
                await asyncio.sleep(0)
                frame = 0

            frame += DT

        else:
            screen.fill(BG_COLOR)
            screen.blit(background[controller], (0, 0))
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
