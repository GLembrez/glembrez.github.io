import asyncio
import pygame
from math import sqrt, sin, cos, atan, tanh, asin

pygame.init()

# Constants
K = 30
U_MAG = 3.5
GAIN = 0.1
W0 = 3
XI = 0.7
DT = 5*1e-3
WIDTH = 1280
HEIGHT = 720
SCALE = 100
FG_COLOR = (210, 210, 210)
BG_COLOR = (36, 39, 58)

# Global variables
px = 0
px_stored = 0
px_stance = 0
x = [px, 1.7, 0.0, 0.0, 0.0, 0.0]
Ts = 0.1
Ts_stored = 0.1
flight = True
failed = False
Raibert = True
running = True
frame = 0

screen = pygame.display.set_mode([WIDTH, HEIGHT])
clock = pygame.time.Clock()


def ff(x, u, dt, k=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]):
    dx = [x[3], x[4], x[5], 0.0, -1.0, u]
    return [dx[i] + dt * k[i] for i in range(6)]

def fs(x,dt,k=[0.,0.,0.,0.,0.,0.]):
    l = sqrt(x[0] ** 2 + x[1] ** 2)
    dx = [x[3], x[4], 0.0, K * (1 - l) * x[0] / l, K * (1.0 - l) * x[1] / l - 1.0, 0.0]
    return [dx[i] + dt * k[i] for i in range(6)]

def RK4f(x, u):
    k1 = ff(x, u, 0.0)
    k2 = ff(x, u, DT / 2, k1)
    k3 = ff(x, u, DT / 2, k2)
    k4 = ff(x, u, DT, k3)
    return [x[i] + DT / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) for i in range(6)]

def RK4s(x):
    k1 = fs(x, 0.0)
    k2 = fs(x, DT / 2, k1)
    k3 = fs(x, DT / 2, k2)
    k4 = fs(x, DT, k3)
    x_ = [x[i] + DT / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) for i in range(6)]
    x_[2] = atan(-x[0]/x[1])
    x_[5] = x_[0] * x_[4] - x_[1] * x_[3]
    return x_

def TD(x):
    return x[1]<cos(x[2])

def LO(x):
    return x[0] ** 2 + x[1] ** 2 > 1

def uv(P):
    return [P[0] + WIDTH // 2, HEIGHT // 2 - P[1]]


def draw(px, x, flight):
    P1 = [SCALE * px, SCALE * x[1]]
    l = 1.0 if flight else sqrt(x[0] ** 2 + x[1] ** 2)
    P2 = [P1[0] + SCALE * l * sin(x[2]), P1[1] - SCALE * l * cos(x[2])]
    p1 = uv(P1)
    p2 = uv(P2)
    pygame.draw.circle(screen, FG_COLOR, p1, 16)
    pygame.draw.line(screen, FG_COLOR, p1, p2, width=3)
    pygame.draw.line(screen, FG_COLOR, (0, HEIGHT // 2), (WIDTH, HEIGHT // 2), width=3)


async def main():

    global px, px_stored, px_stance, x, Ts, Ts_stored, flight, failed, Raibert, running, frame

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        u = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            running = False
        if keys[pygame.K_LEFT]:
            u = -U_MAG
        if keys[pygame.K_RIGHT]:
            u = U_MAG

        if x[1]<0.0:
            pass 
        else: 
            if flight: 

                if Raibert:
                    vd = 1.5 * tanh(100*u)
                    TD_angle = asin((x[3] * Ts / 2) + GAIN * (x[3] - vd))
                    u = W0**2 * (TD_angle - x[2]) - 2*XI*W0 * x[5]

                x = RK4f(x,u)
                px = x[0]
                if TD(x):
                    flight = False
                    px_stored = px
                    px_stance = -sin(x[2])
                    x[0] = -sin(x[2])
                    Ts_stored = 0
            else:
                x = RK4s(x)
                px = px_stored + x[0] - px_stance
                Ts_stored += DT
                if LO(x):
                    flight = True
                    x[0] = px
                    Ts = Ts_stored



        if frame >= 0.06:
            screen.fill(BG_COLOR)
            draw(px, x, flight)
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
            frame = 0

        frame += DT

    pygame.quit()


asyncio.run(main())
